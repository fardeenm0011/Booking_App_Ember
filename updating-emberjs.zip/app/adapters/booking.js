import ApplicationAdapter from './application';

export default class BookingAdapter extends ApplicationAdapter {}
